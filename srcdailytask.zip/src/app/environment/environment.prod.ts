export const environment = {
<<<<<<< HEAD
    production: true,
     //localUrl:"http://167.99.234.75:3000/"
    localUrl:"http://localhost:3000/"
  };
=======
  production: true,
  productionUrl: 'http://167.99.234.75:3000/',
};
>>>>>>> e8d74e36e2e701da04ee9b377cb8723925663a41
