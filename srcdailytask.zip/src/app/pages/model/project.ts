export class Project{
    id:number=0;
    name:string='';
    teamLead:string='';
    startDate!:Date;
    expectedEndDate!:Date;
}