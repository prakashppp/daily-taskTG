export class User{
    id:number=0;
    Name:string='';
    Email:string='';
    Mobile:number=0;
    UserType:string='';
    //Project:string='';
    Project:string[]=[];
}