export const environment = {
    production: true,
     //localUrl:"http://167.99.234.75:3000/"
    localUrl:"http://localhost:3000/"
  };
