export interface Emp{
    id:number;
    name:string;
    date:Date;
    tasks:string[];
    projects:string;
}